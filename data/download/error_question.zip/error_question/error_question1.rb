def myoji

name1 = "tanaka"
name2 = "suzuki"
name3 = "satoh

puts "Member: #{name1}, #{name2}, #{name3}"

end

myoji
