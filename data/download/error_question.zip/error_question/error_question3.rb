
PI = 3
diameter = 4
height = 10

radius = diametar / 2
circle_s = radius * radius * PI
column_v = circle_s * height

puts "直径が#{diameter},高さが#{height}の円柱の体積は#{column_v}です"
