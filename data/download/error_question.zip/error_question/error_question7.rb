ary = [1,2,3,4]

sum = 0
i = 0
while i <= 4
  sum += ary[i]
  i += 1
end
puts sum

