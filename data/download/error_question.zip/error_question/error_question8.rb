def cal(a_num1, a_num2, a_num3, a_num4)
  sum = a_num1 + a_num2 + a_num3 + a_num4
  return sum
end

num1 = 1
num2 = 2
num3 = 3
num4 = 4

sum = cal(num1, num2)
puts "合計は#{sum}です"
